export const SECTORS = [
  '기술 (Technology)',
  '헬스케어 (Healthcare)',
  '금융 (Financials)',
  '에너지 (Energy)',
  '소비재 (Consumer Discretionary)',
  '산업재 (Industrials)',
  '부동산 (Real Estate)',
  '유틸리티 (Utilities)',
  '신재생에너지 (Renewable Energy)'
];

export const MARKETS = [
  'KOSPI',
  'KOSDAQ',
  'NASDAQ',
  'NYSE',
  'S&P 500',
  '국내 상장 미국 대표 ETF',
  '국내 상장 중국 대표 ETF',
  '국내 상장 일본 대표 ETF',
];